"""
Incredible India Smart Tourism Portal
=======================================
Streamlit app: destination explorer, interactive dashboard, and an
AI-powered persona-based recommendation engine with explainability.

Run: streamlit run app.py
Needs: Top Indian Places to Visit.csv in the same folder (or update DATA_PATH)
"""

import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
import joblib
import os

st.set_page_config(page_title="Incredible India Smart Tourism Portal", page_icon="🇮🇳", layout="wide")

DATA_PATH = "Top Indian Places to Visit.csv"
PERSONA_DATA_PATH = "India_Persona_Recommender_Dataset.csv"   # from Colab Cell 15
MODEL_PATH = "tourism_model.pkl"                                # from Colab Cell 15
MODEL_COLUMNS_PATH = "model_columns.pkl"                        # from Colab Cell 15

# Approximate state centroid coordinates for the state-level map.
# NOTE: the source dataset has no latitude/longitude per destination, so we
# cannot show exact per-monument pins (like Google Maps). This map shows
# STATE-level bubbles instead — honest about the data's real precision.
STATE_COORDS = {
    "Andhra Pradesh": (15.9129, 79.7400), "Arunachal Pradesh": (28.2180, 94.7278),
    "Assam": (26.2006, 92.9376), "Bihar": (25.0961, 85.3131), "Chhattisgarh": (21.2787, 81.8661),
    "Delhi": (28.7041, 77.1025), "Goa": (15.2993, 74.1240), "Gujarat": (22.2587, 71.1924),
    "Haryana": (29.0588, 76.0856), "Himachal Pradesh": (31.1048, 77.1734),
    "Jammu and Kashmir": (33.7782, 76.5762), "Jharkhand": (23.6102, 85.2799),
    "Karnataka": (15.3173, 75.7139), "Kerala": (10.8505, 76.2711), "Ladakh": (34.1526, 77.5770),
    "Madhya Pradesh": (22.9734, 78.6569), "Maharashtra": (19.7515, 75.7139),
    "Manipur": (24.6637, 93.9063), "Meghalaya": (25.4670, 91.3662), "Mizoram": (23.1645, 92.9376),
    "Nagaland": (26.1584, 94.5624), "Odisha": (20.9517, 85.0985), "Punjab": (31.1471, 75.3412),
    "Rajasthan": (27.0238, 74.2179), "Sikkim": (27.5330, 88.5122), "Tamil Nadu": (11.1271, 78.6569),
    "Telangana": (18.1124, 79.0193), "Tripura": (23.9408, 91.9882), "Uttar Pradesh": (26.8467, 80.9462),
    "Uttarakhand": (30.0668, 79.0193), "West Bengal": (22.9868, 87.8550),
    "Andaman and Nicobar Islands": (11.7401, 92.6586), "Chandigarh": (30.7333, 76.7794),
    "Puducherry": (11.9416, 79.8083), "Daman and Diu": (20.3974, 72.8328),
}

PERSONAS = {
    "Budget Backpacker": {"budget_pref": "Low", "significance": ["Nature","Adventure","Trekking","Wildlife"]},
    "Family":             {"budget_pref": "Medium", "significance": ["Recreational","Entertainment","Cultural"]},
    "Honeymoon":          {"budget_pref": "Medium", "significance": ["Scenic","Nature","Botanical"]},
    "Adventure Seeker":   {"budget_pref": "Low", "significance": ["Adventure","Wildlife","Trekking","Sports"]},
    "Pilgrimage":         {"budget_pref": "Low", "significance": ["Religious","Spiritual","Archaeological"]},
}


@st.cache_data
def load_and_clean_data():
    df = pd.read_csv(DATA_PATH)
    df = df.drop(columns=["Unnamed: 0"]).reset_index(drop=True)
    df.insert(0, "destination_id", ["DEST_" + str(i+1).zfill(4) for i in range(len(df))])
    df["State"] = df["State"].replace({"Maharastra": "Maharashtra"})
    df["Weekly Off"] = df["Weekly Off"].fillna("None")
    df["Establishment Year"] = pd.to_numeric(df["Establishment Year"], errors="coerce")

    def budget_tier(fee):
        if pd.isna(fee): return "Unknown"
        if fee <= 50: return "Low"
        if fee <= 500: return "Medium"
        return "High"
    df["Budget_Tier"] = df["Entrance Fee in INR"].apply(budget_tier)
    return df


def match_score(row, prefs):
    score = 0.0
    tiers = ["Low", "Medium", "High"]
    if row["Budget_Tier"] in tiers:
        d = abs(tiers.index(row["Budget_Tier"]) - tiers.index(prefs["budget_pref"]))
        score += max(0, 3 - d * 1.5)
    if row["Significance"] in prefs["significance"]:
        score += 4
    score += (row["Google review rating"] - 3.0) * 1.5
    return round(score, 2)


@st.cache_data
def load_persona_dataset(df):
    """Uses YOUR real Colab-generated dataset if present. Falls back to
    rebuilding it in-app only if the Colab export is missing, so the app
    still runs for local testing — but the real submission should always
    ship with the actual Colab-exported CSV."""
    if os.path.exists(PERSONA_DATA_PATH):
        return pd.read_csv(PERSONA_DATA_PATH)
    st.warning(f"'{PERSONA_DATA_PATH}' not found — rebuilding persona dataset in-app as a fallback. "
               "For the real submission, run Colab Cell 15 and place its output files here.")
    rows = []
    for _, d in df.iterrows():
        for persona, prefs in PERSONAS.items():
            r = d.to_dict()
            r["Persona"] = persona
            r["Match_Score"] = match_score(d, prefs)
            rows.append(r)
    combined = pd.DataFrame(rows)
    combined["Is_Recommended"] = (combined["Match_Score"] >= combined["Match_Score"].median()).astype(int)
    return combined


@st.cache_resource
def load_trained_model():
    """Loads the ACTUAL tuned model from your Colab pipeline (Cell 13-15) —
    the same Gradient Boosting model that scored 92.9% after GroupKFold
    tuning, not a fresh model retrained inside the app."""
    if os.path.exists(MODEL_PATH) and os.path.exists(MODEL_COLUMNS_PATH):
        model = joblib.load(MODEL_PATH)
        model_columns = joblib.load(MODEL_COLUMNS_PATH)
        return model, model_columns, True
    st.warning(f"'{MODEL_PATH}' not found — training a fallback model in-app instead. "
               "For the real submission, run Colab Cell 15 and place tourism_model.pkl here.")
    from sklearn.model_selection import GroupShuffleSplit
    from sklearn.ensemble import RandomForestClassifier
    features = ["Persona", "Type", "Entrance Fee in INR", "time needed to visit in hrs", "Google review rating"]
    X = pd.get_dummies(combined[features], columns=["Persona", "Type"])
    y = combined["Is_Recommended"]
    gss = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
    train_idx, _ = next(gss.split(X, y, groups=combined["destination_id"]))
    model = RandomForestClassifier(n_estimators=200, random_state=42)
    model.fit(X.iloc[train_idx], y.iloc[train_idx])
    return model, X.columns.tolist(), False


df = load_and_clean_data()
combined = load_persona_dataset(df)
model, model_columns, using_real_model = load_trained_model()

# ---------------------------------------------------------------------------
# SIDEBAR NAVIGATION
# ---------------------------------------------------------------------------
st.sidebar.title("🇮🇳 Tourism Portal")
page = st.sidebar.radio("Navigate", [
    "🏠 Home", "📊 Dashboard", "🔍 Explore & Search",
    "🧠 AI Recommendation", "⚖ Compare Destinations",
])

# ---------------------------------------------------------------------------
# HOME PAGE
# ---------------------------------------------------------------------------
if page == "🏠 Home":
    st.markdown("""
    <div style="
        background: linear-gradient(135deg, #FF9933 0%, #FFFFFF 50%, #138808 100%);
        padding: 50px 30px; border-radius: 12px; text-align: center; margin-bottom: 25px;">
        <h1 style="color:#1a1a1a; margin-bottom:5px;">🇮🇳 Incredible India</h1>
        <h3 style="color:#333; font-weight:400; margin-top:0;">Smart Tourism Portal — Powered by AI</h3>
        <p style="color:#444; font-size:16px;">🏔 Mountains &nbsp;·&nbsp; 🏖 Beaches &nbsp;·&nbsp; 🛕 Heritage &nbsp;·&nbsp; 🌿 Wildlife &nbsp;·&nbsp; 🏞 Nature</p>
    </div>
    """, unsafe_allow_html=True)

    st.title("Discover India's Best Destinations")
    st.subheader("Using Artificial Intelligence")
    st.markdown("Explore, compare, and get a personalized recommendation — powered by machine learning.")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("📍 Destinations", len(df))
    c2.metric("🏞 States", df["State"].nunique())
    c3.metric("🧭 Categories", df["Type"].nunique())
    c4.metric("⭐ Avg Rating", round(df["Google review rating"].mean(), 2))

    st.divider()
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("### 🔥 Top-Rated Destinations")
        top = df.nlargest(5, "Google review rating")[["Name", "State", "Google review rating"]]
        st.dataframe(top, hide_index=True, use_container_width=True)
    with col2:
        st.markdown("### 💰 Best Value Picks (Free/Low-cost, high rated)")
        value = df[df["Budget_Tier"] == "Low"].nlargest(5, "Google review rating")[["Name", "State", "Google review rating"]]
        st.dataframe(value, hide_index=True, use_container_width=True)

# ---------------------------------------------------------------------------
# DASHBOARD PAGE
# ---------------------------------------------------------------------------
elif page == "📊 Dashboard":
    st.title("📊 Interactive Tourism Dashboard")

    with st.expander("Filters", expanded=True):
        c1, c2, c3 = st.columns(3)
        state_filter = c1.multiselect("State", sorted(df["State"].unique()))
        type_filter = c2.multiselect("Type", sorted(df["Type"].unique()))
        budget_filter = c3.multiselect("Budget Tier", sorted(df["Budget_Tier"].unique()))

    filtered = df.copy()
    if state_filter: filtered = filtered[filtered["State"].isin(state_filter)]
    if type_filter: filtered = filtered[filtered["Type"].isin(type_filter)]
    if budget_filter: filtered = filtered[filtered["Budget_Tier"].isin(budget_filter)]

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Destinations (filtered)", len(filtered))
    c2.metric("Avg Rating", round(filtered["Google review rating"].mean(), 2) if len(filtered) else "-")
    c3.metric("Avg Entry Fee", f"₹{round(filtered['Entrance Fee in INR'].mean())}" if len(filtered) else "-")
    c4.metric("States Represented", filtered["State"].nunique())

    st.divider()
    col1, col2 = st.columns(2)
    with col1:
        top_states = filtered["State"].value_counts().head(10).reset_index()
        top_states.columns = ["State", "Count"]
        fig = px.bar(top_states, x="State", y="Count", title="Top States by Destination Count")
        st.plotly_chart(fig, use_container_width=True)
    with col2:
        type_counts = filtered["Type"].value_counts().head(10).reset_index()
        type_counts.columns = ["Type", "Count"]
        fig = px.pie(type_counts, names="Type", values="Count", title="Destination Type Split")
        st.plotly_chart(fig, use_container_width=True)

    st.markdown("### 🗺 State-wise Map")
    st.caption("Note: exact per-destination coordinates aren't in the source data, so this shows "
               "state-level totals rather than individual destination pins.")
    state_summary = filtered.groupby("State").agg(Count=("Name","count"), Avg_Rating=("Google review rating","mean")).reset_index()
    state_summary["lat"] = state_summary["State"].map(lambda s: STATE_COORDS.get(s, (None,None))[0])
    state_summary["lon"] = state_summary["State"].map(lambda s: STATE_COORDS.get(s, (None,None))[1])
    state_summary = state_summary.dropna(subset=["lat","lon"])
    if len(state_summary):
        fig = px.scatter_mapbox(state_summary, lat="lat", lon="lon", size="Count", color="Avg_Rating",
                                 hover_name="State", hover_data=["Count","Avg_Rating"],
                                 zoom=3.5, height=500, color_continuous_scale="Viridis")
        fig.update_layout(mapbox_style="open-street-map", margin={"r":0,"t":0,"l":0,"b":0})
        st.plotly_chart(fig, use_container_width=True)

# ---------------------------------------------------------------------------
# EXPLORE & SEARCH PAGE
# ---------------------------------------------------------------------------
elif page == "🔍 Explore & Search":
    st.title("🔍 Explore Destinations")
    search = st.text_input("Search by name or city")

    results = df.copy()
    if search:
        mask = df["Name"].str.contains(search, case=False, na=False) | df["City"].str.contains(search, case=False, na=False)
        results = df[mask]

    st.write(f"{len(results)} destination(s) found")
    for _, row in results.head(20).iterrows():
        with st.container(border=True):
            c1, c2 = st.columns([3,1])
            with c1:
                st.markdown(f"**{row['Name']}** — {row['City']}, {row['State']}")
                st.caption(f"{row['Type']} · {row['Significance']}")
            with c2:
                st.metric("Rating", f"{row['Google review rating']} ⭐")
            c3, c4, c5 = st.columns(3)
            c3.write(f"💰 ₹{row['Entrance Fee in INR']}")
            c4.write(f"⏱ {row['time needed to visit in hrs']} hrs")
            c5.write(f"📊 {row['Budget_Tier']} budget")

# ---------------------------------------------------------------------------
# AI RECOMMENDATION PAGE
# ---------------------------------------------------------------------------
elif page == "🧠 AI Recommendation":
    st.title("🧠 Find My Perfect Trip")
    st.markdown("Tell us about yourself, and our AI will recommend the best-matching destinations.")

    c1, c2 = st.columns(2)
    with c1:
        persona = st.radio("What type of traveller are you?", list(PERSONAS.keys()))
    with c2:
        budget_choice = st.radio("Budget", ["Low", "Medium", "High"])
        state_choice = st.selectbox("Preferred State (optional)", ["Any"] + sorted(df["State"].unique()))

    if st.button("🔎 Find My Trip", type="primary"):
        prefs = PERSONAS[persona].copy()
        prefs["budget_pref"] = budget_choice  # let user's chosen budget override the persona default

        candidates = df.copy()
        if state_choice != "Any":
            candidates = candidates[candidates["State"] == state_choice]

        candidates = candidates.copy()
        candidates["Match_Score"] = candidates.apply(lambda r: match_score(r, prefs), axis=1)

        # AI Confidence: use the trained classifier's own probability estimate
        cand_features = candidates.copy()
        cand_features["Persona"] = persona
        X_cand = pd.get_dummies(cand_features[["Persona","Type","Entrance Fee in INR","time needed to visit in hrs","Google review rating"]],
                                 columns=["Persona","Type"])
        X_cand = X_cand.reindex(columns=model_columns, fill_value=0)
        candidates["AI_Confidence"] = model.predict_proba(X_cand)[:, 1]

        top_matches = candidates.sort_values("Match_Score", ascending=False).head(5)

        if len(top_matches) == 0:
            st.warning("No destinations found for this combination — try a different state or budget.")
        else:
            best = top_matches.iloc[0]
            st.success(f"🏆 BEST MATCH: **{best['Name']}**, {best['State']}")
            c1, c2, c3 = st.columns(3)
            c1.metric("Match Score", f"{best['Match_Score']} / 10")
            c2.metric("AI Confidence", f"{best['AI_Confidence']*100:.0f}%")
            c3.metric("Rating", f"{best['Google review rating']} ⭐")

            st.markdown("**Why this place?**")
            reasons = []
            if best["Budget_Tier"] == budget_choice: reasons.append(f"✔ Matches your {budget_choice} budget")
            if best["Significance"] in PERSONAS[persona]["significance"]: reasons.append(f"✔ {best['Significance']} — fits {persona} interests")
            if best["Google review rating"] >= 4.5: reasons.append("✔ Highly rated by visitors")
            if best["Entrance Fee in INR"] <= 100: reasons.append("✔ Low cost entry")
            for r in reasons:
                st.write(r)

            st.divider()
            st.markdown("### Similar destinations you might like")
            for _, row in top_matches.iloc[1:].iterrows():
                st.write(f"**{row['Name']}**, {row['State']} — {row['Google review rating']}⭐ · Match {row['Match_Score']}/10")

# ---------------------------------------------------------------------------
# COMPARE DESTINATIONS PAGE
# ---------------------------------------------------------------------------
elif page == "⚖ Compare Destinations":
    st.title("⚖ Compare Destinations")
    c1, c2 = st.columns(2)
    dest_a = c1.selectbox("Destination A", df["Name"].sort_values(), index=0)
    dest_b = c2.selectbox("Destination B", df["Name"].sort_values(), index=1)

    row_a = df[df["Name"] == dest_a].iloc[0]
    row_b = df[df["Name"] == dest_b].iloc[0]

    compare_df = pd.DataFrame({
        "Metric": ["State","Type","Rating","Entrance Fee","Time Needed (hrs)","Budget Tier"],
        dest_a: [row_a["State"], row_a["Type"], row_a["Google review rating"], row_a["Entrance Fee in INR"], row_a["time needed to visit in hrs"], row_a["Budget_Tier"]],
        dest_b: [row_b["State"], row_b["Type"], row_b["Google review rating"], row_b["Entrance Fee in INR"], row_b["time needed to visit in hrs"], row_b["Budget_Tier"]],
    })
    st.table(compare_df.set_index("Metric"))

    winner = dest_a if row_a["Google review rating"] > row_b["Google review rating"] else dest_b
    st.info(f"🏆 Higher rated: **{winner}**")
